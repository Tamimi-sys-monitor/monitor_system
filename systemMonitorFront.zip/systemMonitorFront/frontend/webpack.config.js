export const devServer = {
  // Other devServer options...
  headers: {
    "Content-Type": "application/javascript",
  },
};
